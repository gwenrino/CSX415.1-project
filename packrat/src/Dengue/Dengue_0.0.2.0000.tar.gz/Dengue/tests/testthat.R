library(testthat)
library(Dengue)

test_check("Dengue")
